<?php
/*
 * Dev: KO
 * Description: 
 * Version: 0.9
*/

    /* Kontakt */
    $telefon = "015792478830";
   
    $email = "info@schluesseldienst-huckelhoven.de";

    /* Social Media */
    $facebook = "https://www.facebook.com/";
    $instagram = "https://www.instagram.com/";
    $twitter = "https://twitter.com/";
    $pinterest = "https://www.pinterest.de/";
    $youtube = "https://www.youtube.com/";

    /* Schema */
    $latitude = "51.0552";
    $longitude = "6.2247";
    $stadt = "Hückelhoven";
    $plz = "41836";

    /* .. */
    $name = "Schlüsseldienst Hückelhoven";
    $description = "Ihr regionaler Schlüsseldienst für Hückelhoven - Unser 24 Stunden Service ist immer für Sie da.";

    /* Karte */
    $map = '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d80281.34054671731!2d6.159518089433051!3d51.03846426945213!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47c0a8e2afebe68f%3A0x41ef7a879aca9b9f!2s41836%20H%C3%BCckelhoven%2C%20Deutschland!5e0!3m2!1sde!2sma!4v1589993425641!5m2!1sde!2sma" width="100%" height="250" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>';

?>
